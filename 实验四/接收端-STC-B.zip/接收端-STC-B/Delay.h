#ifndef _DELAY_H_
#define _DELAY_H_
#include "intrins.h"

//void Delayms(char i);
void Delayus(int i);
void Delayms(char i);
void Delay(char n);
#endif