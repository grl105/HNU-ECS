#include <STC15F2K60S2.H>
#include <intrins.h>
#include "reg51.h"

#define uint  unsigned int
#define uchar unsigned char
#define ulong unsigned long


extern uint lightflag;
// adc_isr() interrupt 5 using 1;