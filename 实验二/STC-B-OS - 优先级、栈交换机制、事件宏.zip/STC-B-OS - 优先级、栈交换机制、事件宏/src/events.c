#include "events.h"

XDATA u32 curr_events = 0;
XDATA u8 proc_waiting_evt = 0;
XDATA u32 proc_listening_list[8] = {0,0,0,0,0,0,0,0};
/*
    Example: process P waiting on event EVT_XXX and EVT_YYY
    proc_waiting_evt.bit[P] = 1;
    proc_listening_list[P] = EVT_XXX | EVT_YYY;
*/

void dispatch_events(u8 pid)
{
    if(proc_waiting_evt & BIT(pid))
    {
        if(proc_listening_list[pid] & curr_events)
        {
            /*
            process can read this to know which of 
            the listened events is actually occured.
            */
            proc_listening_list[pid] = curr_events; 
            CLEARBIT(proc_waiting_evt, pid);
        }
				else if((proc_listening_list[pid] & EVT_TIMER) && (proc_sleep_countdown[pid]==0))
				{
					  proc_listening_list[pid] = EVT_TIMER; 
            CLEARBIT(proc_waiting_evt, pid);
				}
    }
}

void collect_btnevts()
{
	update_button_state();

    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_B1 ? EVT_BTN1_DN : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_B2 ? EVT_BTN2_DN : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_B3 ? EVT_BTN3_DN : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_UP ? EVT_NAV_U : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_DOWN ? EVT_NAV_D : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_LEFT ? EVT_NAV_L : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_RIGHT ? EVT_NAV_R : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_PUSH ? EVT_NAV_PUSH : 0);

    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_B1 ? EVT_BTN1_UP : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_B2 ? EVT_BTN2_UP : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_B3 ? EVT_NAV_BTN3_RESET : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_UP ? EVT_NAV_BTN3_RESET : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_DOWN ? EVT_NAV_BTN3_RESET : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_LEFT ? EVT_NAV_BTN3_RESET : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_RIGHT ? EVT_NAV_BTN3_RESET : 0);
    SET_EVENT_FLAG(btnstate_posedge & BTNSTATE_PUSH ? EVT_NAV_BTN3_RESET : 0);
}


void collect_uartevts() //VOID
{
	if(rs485_evtstate)
	{
			rs485_evtstate = 0;
			SET_EVENT_FLAG(EVT_UART2_RECV);
	}
	if(usbcom_evtstate)
	{
            usbcom_evtstate = 0;
            SET_EVENT_FLAG(EVT_UART1_RECV);
	}
}


void process_events() //VOID
{
    curr_events = 0;
    
    collect_btnevts();
    collect_uartevts();

		dispatch_events(0);
		dispatch_events(1);
		dispatch_events(2);
		dispatch_events(3);
		dispatch_events(4);
		dispatch_events(5);
		dispatch_events(6);
		dispatch_events(7);
}